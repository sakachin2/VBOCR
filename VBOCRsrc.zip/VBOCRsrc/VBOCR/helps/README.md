﻿# VBOCR                    2017/01/06 v1.05

Tool of TextExtraction from image file using Microsoft OCR Library for Windows (Windows10).
To install, double click SetupVBOCR.msi.

*************************************************************************

(Japanese)
Windows10:Microsoft OCR Library for Windows を利用して
スキャナーで読み取ったイメージファイルから漢字かな混じり文を読み取ります
インストールは SetupVBOCR.msi をダブルクリックしてください
