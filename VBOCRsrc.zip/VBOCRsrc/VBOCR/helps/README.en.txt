(UTF8 encoding)
*********************************************************************************************
V1.08 : 2018/09/22 

(Bug)"OK" buttun of dialog showing partially extracted text replaces a character on the cursor.
"OpenFile" Menu button supports MRU(MostRecentlyUsed) up to 10 files.

V1.07 : 2018/03/17 

.Reverse display one char on caret position even when focus lost 
 for sending text by OK button of paqrtial extracted text form.
.Send by OK button accept patial text by mouse dragging.

V1.06 : 2018/01/08 

Adjust marking position of recognized char when rotated by one degree.

V1.05 : 2018/01/06 

Support rotation by 1 degree each to enable recognize image with a litte slope.

V1.04 : 2017/12/28 

Set boundery of image and text panel to movable.

V1.03 : 2017/12/25 

Supports output the potion of the image to file.

V1.02 : 2017/12/21 

Supports partial extracting in the box by mouse dragging.

V1.01 : 2017/12/14 (1st release)
Tool of TextExtraction from image file using Microsoft OCR Library for Windows (Windows10).
You can get image file by "Windows Fax and Scan" etc.

To install, double click SetupVBOCR.msi on Explorer.
Application name on ControlPanel is sampleVBOCR
MSVS2017 Comunity project source is on GitHub sakachin2/VBOCR.
See also GitHub sakachin2/VBI2KWRT for function of text manipulation.

Please send your sudgestion or bug reports to mail:sakachin2@yahoo.co.jp

*************************************************************************************
