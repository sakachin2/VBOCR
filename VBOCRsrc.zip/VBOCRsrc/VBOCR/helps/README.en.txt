(UTF8 encoding)
*********************************************************************************************
V1.01 : 2017/12/14 (1st release)
Tool of TextExtraction from image file using Microsoft OCR Library for Windows (Windows10).
You can get image file by "Windows Fax and Scan" etc.

To install, double click SetupVBOCR.msi on Explorer.
Application name on ControlPanel is sampleVBOCR
MSVS2017 Comunity project source is on GitHub sakachin2/VBOCR.

Please send your sudgestion or bug reports to mail:sakachin2@yahoo.co.jp

*************************************************************************************
