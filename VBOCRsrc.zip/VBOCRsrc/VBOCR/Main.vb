﻿Module Main
    <STAThread()> Sub Main()
        Application.Run(New Form1())
    End Sub
End Module
